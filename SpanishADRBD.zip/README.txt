
DRUGDATABASE Load Instructions

File 'DRUGDATABASE.sql' contains a dump of the database 'DRUGDATABASE' and can be restored using the command:
mysql -u #username# -p #databasename# < DrugDatabase.sql
where #username# is the access user of the database and #databasename# is the database where you can load the data
